import 'package:flutter/material.dart';
import 'package:tree_clinic/app/tree_clinic.dart';

void main() {
  runApp(const TreeClinic());
}
