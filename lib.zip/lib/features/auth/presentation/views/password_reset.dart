// import 'package:flutter/material.dart';
// import 'package:login/Pages/OTP_screen.dart';
// import 'package:login/Pages/new_password.dart';
// import 'package:login/constants.dart';
// import 'package:login/widgets/custom_button.dart';
// import 'package:login/widgets/custom_text_field.dart';

// class PasswordReset extends StatelessWidget {
//   PasswordReset({super.key});
//   String id = "PasswordReset";
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: kPrimaryColor,
//       appBar: AppBar(backgroundColor: kPrimaryColor, actions: <Widget>[
//         ],
//       ),
//       body: Padding(
//         padding: const EdgeInsets.symmetric(horizontal: 16),
//         child: ListView(
//           shrinkWrap:
//               true, // Tells the ListView to be only as tall as its children
//           physics: NeverScrollableScrollPhysics(),
//           children: [
//             Text("Password Reset", style: TextStyle(fontSize: 30)),
//             SizedBox(height: 20),
//             Text(
//               "Your password has been successfully reset. click confirm to set a new password",
//               style: TextStyle(color: kseconderyColor, fontSize: 15),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(top: 20),
//               child: GestureDetector(
//                 onTap: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(builder: (context) => NewPassword()),
//                   );
//                 },
//                 child: CustomButton(name: "Confirm"),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//     ;
//   }
// }
