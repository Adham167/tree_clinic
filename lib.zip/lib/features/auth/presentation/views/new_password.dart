// import 'package:flutter/material.dart';
// import 'package:login/Pages/OTP_screen.dart';
// import 'package:login/Pages/success_reset_password.dart';
// import 'package:login/constants.dart';
// import 'package:login/widgets/custom_button.dart';
// import 'package:login/widgets/custom_text_field.dart';

// class NewPassword extends StatelessWidget {
//   NewPassword({super.key});
//   String id = "ForgetPassword";
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: kPrimaryColor,
//       appBar: AppBar(backgroundColor: kPrimaryColor, actions: <Widget>[
//         ],
//       ),
//       body: Padding(
//         padding: const EdgeInsets.symmetric(horizontal: 16),
//         child: ListView(
//           shrinkWrap:
//               true, // Tells the ListView to be only as tall as its children
//           physics: NeverScrollableScrollPhysics(),
//           children: [
//             Text("Set a New Password", style: TextStyle(fontSize: 30)),
//             SizedBox(height: 20),
//             Text(
//               "Create a new password. Ensure it differs from previous ones for security",
//               style: TextStyle(color: kseconderyColor, fontSize: 15),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(top: 30),
//               child: CustomTextField(hint: "Password", text: "Password"),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(top: 10),
//               child: CustomTextField(
//                 hint: "Confirm Password",
//                 text: "Confirm Password",
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(top: 20),
//               child: GestureDetector(
//                 onTap: () {
//                   Navigator.pushNamed(context, SuccessResetPassword().id);
//                 },
//                 child: CustomButton(name: "Reset Password"),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//     ;
//   }
// }
