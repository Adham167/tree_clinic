// import 'package:flutter/material.dart';
// import 'package:login/constants.dart';
// import 'package:login/widgets/custom_button.dart';

// class SucessSignUp extends StatelessWidget {
//   SucessSignUp({super.key});
//   String id = "SucessSignUp";
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: kPrimaryColor,
//       body: Padding(
//         padding: const EdgeInsets.symmetric(horizontal: 16),
//         child: Column(
//           children: [
//             SizedBox(height: 250),
//             Center(
//               child: Image.asset(
//                 "assets/images/Screenshot 2025-10-27 172055.png",
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(top: 30),
//               child: Text("Successful", style: TextStyle(fontSize: 30)),
//             ),
//             SizedBox(height: 50),
//             CustomButton(name: "Continue"),
//           ],
//         ),
//       ),
//     );
//   }
// }
